function increase(id){
    var element = document.querySelector(id);
    element.innerText=parseInt(element.innerText)+1 ; 


}